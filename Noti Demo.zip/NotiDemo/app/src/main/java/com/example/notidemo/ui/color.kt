package com.example.notidemo.ui

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF757575)
val Purple700 = Color(0xFF757575)
val Teal200 = Color(0xFF03DAC5)